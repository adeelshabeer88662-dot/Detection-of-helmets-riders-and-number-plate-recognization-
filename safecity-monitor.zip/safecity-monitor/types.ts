
export enum ViolationType {
  NO_HELMET = 'NO_HELMET',
  COMPLIANT = 'COMPLIANT'
}

export interface BoundingBox {
  ymin: number;
  xmin: number;
  ymax: number;
  xmax: number;
}

export interface DetectionResult {
  id: string;
  timestamp: number;
  type: ViolationType;
  plateNumber: string;
  headBox: BoundingBox;
  plateBox: BoundingBox;
  screenshot: string;
  confidence: number;
  source: string;
}

export interface CameraNode {
  id: string;
  label: string;
  status: 'Online' | 'Standby' | 'Offline' | 'Issue';
  ipAddress: string;
  lastActive: number;
}

export interface StatsData {
  totalRiders: number;
  violations: number;
  platesIdentified: number;
  uptime: string;
}

export interface NavItem {
  id: string;
  label: string;
  icon: string;
}
