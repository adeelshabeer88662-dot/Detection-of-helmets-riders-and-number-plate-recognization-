
export const COLORS = {
  background: '#0F172A',
  surface: '#1E293B',
  accentRed: '#EF4444',
  accentGreen: '#10B981',
  accentOrange: '#F59E0B',
  textPrimary: '#F8FAFC',
  textSecondary: '#94A3B8'
};

export const STORAGE_KEY = 'safecity_detections';
export const THRESHOLD_KEY = 'safecity_threshold';
